idproduto=0;
nomeProduto="";
valorproduto=0;
function adicionarProduto(){
    alert("adicionar")
}